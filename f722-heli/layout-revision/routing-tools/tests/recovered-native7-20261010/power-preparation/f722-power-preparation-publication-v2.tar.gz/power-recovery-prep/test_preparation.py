#!/usr/bin/env python3
"""Mesh-free negative checks for physical source and corrected-terminal gates."""
import argparse
import copy
from pathlib import Path
import unittest
import prepare_final_power as p

SOURCE = p.ROOT.parent / 'recovered-native7/ordinary-routing/tests/native13-access/joint-native-import11-v1/candidates/published-reference02'

class PhysicalGuards(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.board = SOURCE / 'f722-heli.kicad_pcb'
        cls.native = p.read(SOURCE / 'f722-heli.native.json')
        cls.registry = p.read(p.MINIMUM / 'terminal-registry.json')
        cls.plan = p.read(p.MINIMUM / 'case-plan.json')
        cls.rebound = p.read(p.MINIMUM / 'rebound-terminals.json')

    def test_complete_current_contact_audit(self):
        rows, physical, changes = p.audit_mapping(self.board, self.native, self.registry, self.plan, self.rebound)
        self.assertEqual(len(rows), 109)
        self.assertEqual(len(physical), 93)
        self.assertEqual({c['pad'] for c in changes}, {'R42.1', 'R44.2'})

    def test_TPS_enable_cannot_replace_supply(self):
        registry = copy.deepcopy(self.registry)
        registry['contacts']['U10.6']['pads'] = ['U10.4']
        with self.assertRaisesRegex(p.Refused, 'Historical rebound contact disagrees'):
            p.audit_mapping(self.board, self.native, registry, self.plan, self.rebound)

    def test_export_cannot_misstate_source_copper_layer(self):
        objects = [dict(row, copper={'F.Cu': row['copper']['B.Cu']})
                   if row.get('key') == 'R42.1' else row for row in self.native['objects']]
        with self.assertRaisesRegex(p.Refused, 'PCB/native copper layers disagree'):
            p.audit_mapping(self.board, dict(self.native, objects=objects), self.registry, self.plan, self.rebound)

    def test_export_cannot_misstate_pad_location(self):
        objects = [dict(row, xy=[row['xy'][0] + .01, row['xy'][1]])
                   if row.get('key') == 'U11.6' else row for row in self.native['objects']]
        with self.assertRaisesRegex(p.Refused, 'PCB/native pad position disagrees'):
            p.audit_mapping(self.board, dict(self.native, objects=objects), self.registry, self.plan, self.rebound)

    def test_wrong_board_hash_cannot_prepare(self):
        args = argparse.Namespace(source=str(SOURCE), out=str(p.ROOT / 'must-not-be-created'),
            native_name='f722-heli.native.json', expected_board_sha='0' * 64,
            expected_native_sha='53ddf869c36da4a026880c6b3346dd1ddb304aaabaa948b20f1e66fc3db62505')
        with self.assertRaisesRegex(p.Refused, 'Explicit board hash differs'):
            p.prepare(args)
        self.assertFalse(Path(args.out).exists())

if __name__ == '__main__':
    unittest.main()
