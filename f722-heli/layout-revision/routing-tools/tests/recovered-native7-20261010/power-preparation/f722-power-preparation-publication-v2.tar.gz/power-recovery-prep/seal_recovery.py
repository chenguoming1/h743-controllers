#!/usr/bin/env python3
"""Seal or verify the compact power recovery source package; no electrical run."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'PACKAGE-MANIFEST.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def members():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and p != MANIFEST
                  and '__pycache__' not in p.parts and p.suffix != '.pyc')

def verify():
    data = json.loads(MANIFEST.read_text())
    actual = {str(p.relative_to(ROOT)) for p in members()}
    expected = {r['path'] for r in data['files']}
    if actual != expected:
        raise RuntimeError('Package file inventory changed')
    for row in data['files']:
        p = ROOT / row['path']
        if p.is_symlink() or p.stat().st_size != row['bytes'] or sha(p) != row['sha256']:
            raise RuntimeError('Package member changed: ' + row['path'])
    import prepare_final_power
    prepare_final_power.verify_recovery()
    receipt = json.loads((ROOT / 'prepared-native7-v4-disabled/preparation-receipt.json').read_text())
    if receipt['script_sha256'] != sha(ROOT / 'prepare_final_power.py'):
        raise RuntimeError('Preparation source changed after audit')
    for name, digest in receipt['prepared_files_sha256'].items():
        if sha(ROOT / 'prepared-native7-v4-disabled' / name) != digest:
            raise RuntimeError('Prepared input changed: ' + name)
    return data

def seal(destination):
    if MANIFEST.exists() or destination.exists():
        raise RuntimeError('Use a fresh package/manifest destination; do not reseal over an old identity')
    paths = members()
    for p in paths:
        if p.is_symlink() or p.stat().st_size > 2_000_000:
            raise RuntimeError('Unexpected link or large source-package member: ' + str(p))
    data = {'schema': 'f722-power-recovery-source-package/v1',
        'status': 'DISABLED PREPARATION; power STALE; no electrical acceptance',
        'files': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                   'sha256': sha(p)} for p in paths]}
    MANIFEST.write_text(json.dumps(data, indent=2) + '\n')
    verify()
    with destination.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w') as archive:
                for p in sorted(paths + [MANIFEST]):
                    info = archive.gettarinfo(str(p), arcname='power-recovery-prep/' + str(p.relative_to(ROOT)))
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    info.mtime = 0
                    info.mode = 0o644
                    with p.open('rb') as stream:
                        archive.addfile(info, stream)
    return {'package': str(destination), 'bytes': destination.stat().st_size,
            'sha256': sha(destination), 'manifest_sha256': sha(MANIFEST),
            'payload_files': len(paths), 'payload_bytes': sum(r['bytes'] for r in data['files']),
            'numerical_execution_authorized': False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.verify:
        data = verify()
        print(json.dumps({'verified': True, 'payload_files': len(data['files']),
                          'manifest_sha256': sha(MANIFEST), 'numerical_execution_authorized': False}))
    else:
        if args.out is None:
            parser.error('--out is required when sealing')
        print(json.dumps(seal(args.out.resolve())))

if __name__ == '__main__':
    main()
