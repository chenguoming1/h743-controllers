#!/usr/bin/env python3
"""Recover/audit corrected F722 inputs. Standard-library preparation, never a solve.

Published source43 files remain untouched. Outputs are disabled proposals, not
an implementation review, final source freeze, numerical release, or acceptance.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
PACKET = ROOT / 'published/f722-heli/layout-revision/power-evidence/corrected-v3-source43'
MINIMUM = ROOT / 'frozen-minimum'
TOKEN = re.compile(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+')
LAYER_CHANGES = {'R42.1': ('+5V_PERIPH', 'ffcaa37f-4c24-41b4-9aba-10376242234e'),
                 'R44.2': ('GND', '69dd15ed-318d-4e07-93df-53253587847d')}
SOURCE_NAMES = ['f722-heli.kicad_pcb', 'owner-native.json', 'parts.json', 'owner-parity.json',
    'owner-process.json', 'owner-mechanical.json', 'owner-critical.json', 'power-audit.json',
    'owner-drc.json', 'owner-drc-all.json', 'owner-protection.json', 'owner-supplemental.json',
    'owner-summary.json', 'owner-adoption.json', 'power-revalidation-required.json',
    'owner-mechanical-geometry.json', 'owner-firmware.json', 'poses-native.json']

class Refused(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise Refused(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def verify_recovery():
    manifest = read(ROOT / 'exact-source-manifest.json')
    for row in manifest['files']:
        path = ROOT / row['local_path']
        raw = path.read_bytes()
        require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'],
                'Recovered dependency changed: ' + row['local_path'])
        if 'git_blob_sha1' in row:
            actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            require(actual == row['git_blob_sha1'], 'Git blob identity changed: ' + row['local_path'])
    return manifest

def parse_board(text):
    stack, roots = [], []
    for match in TOKEN.finditer(text):
        token = match.group()
        if token == '(':
            node = []
            (stack[-1] if stack else roots).append(node)
            stack.append(node)
        elif token == ')':
            require(bool(stack), 'Unbalanced PCB text')
            stack.pop()
        else:
            require(bool(stack), 'PCB atom outside root')
            stack[-1].append(json.loads(token) if token.startswith('"') else token)
    require(not stack and len(roots) == 1 and roots[0][0] == 'kicad_pcb', 'Invalid PCB root')
    return roots[0]

def children(node, name):
    return [n for n in node if isinstance(n, list) and n and n[0] == name]

def one(node, name):
    rows = children(node, name)
    require(len(rows) == 1, 'PCB field absent or ambiguous: ' + name)
    return rows[0]

def pcb_pads(board, required_keys):
    tree = parse_board(board.read_text())
    board_copper = sorted(row[1] for row in one(tree, 'layers')[1:] if row[1].endswith('.Cu'))
    result = {}
    for fp in children(tree, 'footprint'):
        props = {p[1]: p[2] for p in children(fp, 'property')}
        ref = props['Reference']
        at = one(fp, 'at')
        x, y = map(float, at[1:3])
        angle = math.radians(float(at[3]) if len(at) > 3 else 0)
        for pad in children(fp, 'pad'):
            if not pad[1]:
                continue
            key = ref + '.' + pad[1]
            if key not in required_keys:
                continue
            require(key not in result, 'Duplicate numbered PCB pad: ' + key)
            px, py = map(float, one(pad, 'at')[1:3])
            layers = one(pad, 'layers')[1:]
            copper = sorted(l for l in layers if l.endswith('.Cu'))
            if '*.Cu' in copper:
                copper = board_copper
            net = children(pad, 'net')
            result[key] = {'uuid': one(pad, 'uuid')[1], 'net': net[0][-1] if net else '',
                'layers': copper,
                'xy': [x + px * math.cos(angle) + py * math.sin(angle),
                       y - px * math.sin(angle) + py * math.cos(angle)]}
    return result

def audit_mapping(board, native, registry, plan, old_rebound):
    required_keys = set(plan['physical_pad_contract']) | {k for s in registry['contacts'].values() for k in s['pads']}
    source = pcb_pads(board, required_keys)
    numbered = [p for p in native['objects'] if p['kind'] == 'pad' and p.get('key') in required_keys]
    pads = {p['key']: p for p in numbered}
    require(len(pads) == len(numbered), 'Duplicate native numbered pad identity')
    old = {r['name']: r for r in old_rebound['contacts']}
    mapping, corrections = [], []
    for name, spec in registry['contacts'].items():
        historical = old[name]
        require(historical['pads'] == spec['pads'] and historical['net'] == spec['net'],
                'Historical rebound contact disagrees: ' + name)
        for index, key in enumerate(spec['pads']):
            require(key in pads and key in source, 'Missing physical pad: ' + key)
            n, b = pads[key], source[key]
            require(n['uuid'] == b['uuid'] == historical['native_pad_uuids'][index],
                    'Pad UUID changed or source/export disagree: ' + key)
            require(n['net'] == b['net'] == spec['net'], 'Pad net mismatch: ' + key)
            require(sorted(n['copper']) == b['layers'], 'PCB/native copper layers disagree: ' + key)
            require(max(abs(a - c) for a, c in zip(n['xy'], b['xy'])) < 1e-6,
                    'PCB/native pad position disagrees: ' + key)
            if spec['layer'] not in n['copper']:
                require(key in LAYER_CHANGES and name == key and spec['pads'] == [key],
                        'Unreviewed contact layer difference: ' + key)
                net, uuid = LAYER_CHANGES[key]
                require(spec['layer'] == 'F.Cu' and sorted(n['copper']) == ['B.Cu']
                        and spec['net'] == net and n['uuid'] == uuid,
                        'Unexpected physical identity for allowed layer correction: ' + key)
                corrections.append({'contact': name, 'pad': key, 'old_layer': 'F.Cu',
                                    'new_layer': 'B.Cu', 'net': net, 'uuid': uuid, 'xy': n['xy']})
            mapping.append({'contact': name, 'pad': key, 'net': n['net'], 'uuid': n['uuid'],
                            'xy': n['xy'], 'historical_contact_layer': spec['layer'],
                            'actual_copper_layers': sorted(n['copper'])})
    physical = []
    for key, spec in plan['physical_pad_contract'].items():
        require(key in pads and key in source, 'Missing physical contract pad: ' + key)
        n, b = pads[key], source[key]
        require(n['net'] == b['net'] == spec['net'] and sorted(n['copper']) == b['layers'] == spec['layers'],
                'Physical/control/sense contract mismatch: ' + key)
        require(n['uuid'] == b['uuid'] and max(abs(a-c) for a,c in zip(n['xy'], b['xy'])) < 1e-6,
                'Physical contract PCB/native identity differs: ' + key)
        physical.append({'pad': key, 'net': n['net'], 'layers': sorted(n['copper']),
                         'uuid': n['uuid'], 'xy': n['xy'], 'function': spec['function']})
    require(len(registry['contacts']) == 107 and len({r['pad'] for r in mapping}) == 109,
            'Contact coverage differs from reviewed corrected model')
    require({r['pad'] for r in corrections} == set(LAYER_CHANGES),
            'Expected exactly R42.1 and R44.2 F.Cu-to-B.Cu corrections')
    return mapping, physical, corrections

def prepare(args):
    require(not sys.flags.optimize, 'Run without Python -O')
    manifest = verify_recovery()
    source, out = Path(args.source).resolve(), Path(args.out).resolve()
    require(out.is_relative_to(ROOT) and out != ROOT and not out.exists(),
            'Use a fresh isolated output directory below power-recovery-prep')
    board = source / 'f722-heli.kicad_pcb'
    native_path = source / args.native_name
    require(native_path.resolve().parent == source, 'Native input must be local to selected source')
    require(sha(board) == args.expected_board_sha, 'Explicit board hash differs')
    require(sha(native_path) == args.expected_native_sha, 'Explicit native hash differs')
    native, parts = read(native_path), read(source / 'parts.json')
    require(native.get('board_sha256') == args.expected_board_sha and native.get('source_unchanged') is True,
            'Native export is stale or mutating')
    require(native.get('native_version') == '10.0.6', 'Native exporter version requires review')
    sys.path.insert(0, str(PACKET / 'runtime'))
    from model_contract import check_inputs, definition_contract, check_physical_source
    from power_case_model import build_cases, digest, check_corrected_case, sink_probes
    plan = read(MINIMUM / 'case-plan.json')
    registry = read(MINIMUM / 'terminal-registry.json')
    settings = read(PACKET / 'provenance/compiler-settings.json')
    original_contract = check_inputs(plan, registry, settings)
    check_physical_source(parts, native, plan)
    for ref, spec in plan['selected_part_contract'].items():
        require(parts[ref]['proposed_footprint'] == spec['proposed_footprint'],
                'Selected package contract differs: ' + ref)
    mapping, physical, corrections = audit_mapping(board, native, registry, plan,
                                                    read(MINIMUM / 'rebound-terminals.json'))
    proposed_plan, proposed_registry, proposed_settings = map(copy.deepcopy, (plan, registry, settings))
    for change in corrections:
        proposed_registry['contacts'][change['contact']]['layer'] = change['new_layer']
    proposed_plan['source_observation_only'] = {'board_sha256': args.expected_board_sha,
        'native_sha256': args.expected_native_sha,
        'meaning': 'Preparation only. Final routing/refill and source/release review remain required.'}
    proposed_settings['source_stage'] = 'DISABLED preparation proposal; no numerical acceptance'
    proposed_settings['owner_reviewed_model_sha256'] = None
    proposed_contract = definition_contract(proposed_plan, proposed_registry, proposed_settings)
    require(proposed_contract['case_definitions'] == original_contract['case_definitions'],
            'Case definitions changed during contact rebind')
    for key, value in original_contract['job_sha256'].items():
        if key != 'networks':
            require(proposed_contract['job_sha256'][key] == value, 'Fixed physics/cases/VCAP changed: ' + key)
    proposed_plan['model_contract'] = proposed_contract
    proposed_registry['model_contract_sha256'] = digest(proposed_contract)
    check_inputs(proposed_plan, proposed_registry, proposed_settings)
    families, _ = build_cases(proposed_plan, proposed_settings)
    for cases in families.values():
        for case in cases:
            check_corrected_case(case)
    require(len(families['baseline']) == 294 and len(families['servo']) == 11, 'Case family coverage changed')
    require(len(proposed_plan['VCAP_copper_loops']) == 5 and all(
        loop['maximum_ohm'] == 0.035 for loop in proposed_plan['VCAP_copper_loops']), 'VCAP budget changed')
    source_inventory = []
    for name in SOURCE_NAMES:
        p = source / name
        row = {'required_filename': name, 'present': p.is_file()}
        if p.is_file():
            row.update(sha256=sha(p), bytes=p.stat().st_size)
        source_inventory.append(row)
    require(sha(board) == args.expected_board_sha and sha(native_path) == args.expected_native_sha,
            'Source changed during read-only preparation')
    receipt = {'schema': 'f722-corrected-power-recovery-preparation/v1',
        'status': 'PREPARATION ONLY; current power STALE; final solve NOT RUN',
        'preparation_passed': True, 'electrical_acceptance_claimed': False,
        'numerical_execution_authorized': False, 'heavy_execution_enabled': False,
        'board_sha256': args.expected_board_sha, 'native_sha256': args.expected_native_sha,
        'parts_sha256': sha(source / 'parts.json'), 'source_directory': str(source),
        'script_sha256': sha(__file__), 'recovery_manifest_sha256': sha(ROOT / 'exact-source-manifest.json'),
        'published_commit': manifest['commit'], 'counts': proposed_contract['counts'],
        'actual_pad_count': 109, 'physical_contract_pad_count': len(physical),
        'source43_model_contract_sha256': digest(original_contract),
        'proposed_model_contract_sha256': digest(proposed_contract),
        'case_hashes_unchanged': True, 'changed_job_hash_keys': ['networks'],
        'confirmed_registry_corrections': corrections,
        'fixed_material': proposed_settings['material'], 'grids_mm': proposed_settings['mesh_spacings_mm'],
        'convergence': proposed_settings['convergence'], 'limits': proposed_settings['limits'],
        'source_file_inventory': source_inventory,
        'blocking_conditions': [
            'Final routing and final saved native refill are not established by this preparation.',
            'Fresh source receipts, canonical/adoption equality and all applicable native gates must bind the final board.',
            'New immutable implementation/model review must bind the two registry layer changes; source43 review hash cannot authorize them.',
            'Relocate/review the preserved source43 launcher deliberately; its canonical path and source/support-chain expectations remain historical.',
            'Use a fresh final plan, release, job and mesh cache only after routing releases the single shared heavy lane.',
            'Pinned numerical packages/interpreter and native export runtime must be verified before any later solve.'
        ],
        'retained_invalidity': [
            'Pre-correction USB/DSM claims used TPS2553 EN4 as IN and/or DPS368 CSB2/SDO5 as power terminals and remain invalid.',
            'No old 4008-solver claims, old caches, pass counts, 146 replay cases, 140 endpoints or 5532 sensitivities were recovered as acceptance.',
            'Source43 historical overall false/runner exit 1 remains: 18.560272 A single-feed illustration failed all four 6.0 V servo floors outside the 10 A continuous envelope.',
            'Five 35 mOhm VCAP screens cover copper/barrels only; R16 and capacitor ESR are outside that budget.'
        ]}
    out.mkdir(parents=True)
    save(out / 'case-plan.corrected.disabled.json', proposed_plan)
    save(out / 'terminal-registry.corrected.disabled.json', proposed_registry)
    save(out / 'compiler-settings.disabled.json', proposed_settings)
    save(out / 'contact-pad-audit.json', {'board_sha256': args.expected_board_sha,
        'native_sha256': args.expected_native_sha, 'contacts': mapping, 'physical_contract': physical})
    save(out / 'fixed-supply-windows.json', {'BEC': sink_probes('BEC'), 'USB': sink_probes('USB')})
    receipt['prepared_files_sha256'] = {p.name: sha(p) for p in out.iterdir() if p.is_file()}
    save(out / 'preparation-receipt.json', receipt)
    return receipt

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--native-name', default='f722-heli.native.json')
    parser.add_argument('--expected-board-sha', required=True)
    parser.add_argument('--expected-native-sha', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        result = prepare(args)
    except (Refused, OSError, ValueError, KeyError) as exc:
        print(json.dumps({'preparation_passed': False, 'refusal': str(exc),
                          'numerical_execution_authorized': False}), file=sys.stderr)
        return 2
    print(json.dumps({k: result[k] for k in ['status', 'preparation_passed', 'board_sha256',
        'native_sha256', 'counts', 'actual_pad_count', 'confirmed_registry_corrections',
        'numerical_execution_authorized']}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
